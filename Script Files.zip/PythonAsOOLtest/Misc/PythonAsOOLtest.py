from StrategyLib import PlotProfit

PlotProfit.PrintProfit()

#def main():
#    PlotProfit



#if __name__ == '__main__': main()